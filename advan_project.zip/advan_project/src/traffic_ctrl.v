`timescale 1ns/1ps

module traffic_ctrl(
    input  wire clk, rst,
    input  wire VS, PB,
    output reg [2:0] light_main,   // {RED,YEL,GRN}
    output reg [2:0] light_side,   // {RED,YEL,GRN}
    output reg       walk          // 0=RED, 1=GRN
);

    // Timers only for GREEN states (per your project text)
    integer T_MAIN = 60;   // main green minimum
    integer T_SIDE = 40;   // side green fixed
    integer T_PED  = 40;   // pedestrian walk fixed

    // Light encoding
    parameter [2:0] RED    = 3'b100;
    parameter [2:0] YELLOW = 3'b010;
    parameter [2:0] GREEN  = 3'b001;

    // States
    parameter [2:0]
        MG = 3'b000,   // Main Green
        MY = 3'b001,   // Main Yellow 
        AR = 3'b010,   // All Red     
        SG = 3'b011,   // Side Green
        SY = 3'b100,   // Side Yellow 
        PG = 3'b101;   // Pedestrian Walk Green

    reg [2:0] state, next_state;
    reg [5:0] count;        // enough for 0..63

    reg pb_pending;         

    // State + counter + PB queue
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state      <= MG;
            count      <= 0;
            pb_pending <= 1'b0;
        end else begin
            state <= next_state;

           
            if (next_state != state)
                count <= 0;
            else
                count <= count + 1;

          
            if (state == SG && PB)
                pb_pending <= 1'b1;

            // Clear when entering PG (request served)
            if (next_state == PG)
                pb_pending <= 1'b0;
        end
    end

    // Next-state logic (NO timing for MY/AR/SY)
    always @(*) begin
        next_state = state;

        case (state)
            MG: begin
                if (count < T_MAIN-1)
                    next_state = MG;
                else if (VS || PB)        // check requests after min green
                    next_state = MY;
                else
                    next_state = MG;
            end

            
            MY: next_state = AR;

           
            AR: begin
                if (PB || pb_pending)
                    next_state = PG;      // pedestrian has priority
                else
                    next_state = SG;      // otherwise side road
            end

            SG: begin
                if (count >= T_SIDE-1)
                    next_state = SY;
            end

            
            SY: next_state = AR;

            PG: begin
                if (count >= T_PED-1)
                    next_state = AR;
            end

            default: next_state = MG;
        endcase
    end

    // Output logic 
    always @(*) begin
        light_main = RED;
        light_side = RED;
        walk       = 1'b0;

        case (state)
            MG: begin light_main = GREEN;  light_side = RED;    end
            MY: begin light_main = YELLOW; light_side = RED;    end
            AR: begin light_main = RED;    light_side = RED;     end
            SG: begin light_main = RED;    light_side = GREEN;   end
            SY: begin light_main = RED;    light_side = YELLOW; end
            PG: begin light_main = RED;    light_side = RED;   walk = 1; end
        endcase
    end

endmodule


module tb_traffic_ctrl;

    reg clk, rst;
    reg VS, PB;
    wire [2:0] light_main;
    wire [2:0] light_side;
    wire walk;

    traffic_ctrl U1(.clk(clk), .rst(rst),.VS(VS), .PB(PB),.light_main(light_main),.light_side(light_side), .walk(walk));

    // clock
    initial clk = 0;
    always #5 clk = ~clk;

    integer errors;

    // expected outputs
    reg [2:0] expMain, expSide;
    reg expWalk;

    // check outputs every cycle based on state
    always @(*) begin
        // default
        expMain = 3'b100;  // RED
        expSide = 3'b100;  // RED
        expWalk = 1'b0;

        case (U1.state)
            3'b000: begin expMain = 3'b001; expSide = 3'b100; expWalk = 0; end // MG
            3'b001: begin expMain = 3'b010; expSide = 3'b100; expWalk = 0; end // MY
            3'b010: begin expMain = 3'b100; expSide = 3'b100;expWalk = 0; end // AR
            3'b011: begin expMain = 3'b100; expSide = 3'b001; expWalk = 0; end // SG
            3'b100: begin expMain = 3'b100; expSide = 3'b010; expWalk = 0; end // SY
            3'b101: begin expMain = 3'b100; expSide = 3'b100; expWalk = 1; end // PG
            default: begin expMain = 3'b100; expSide = 3'b100; expWalk = 0; end
        endcase
    end

    always @(posedge clk ) begin
        if (!rst) begin
            if (light_main !== expMain || light_side !== expSide || walk !== expWalk) begin
                $display("ERROR t=%0t state=%0d count=%0d | got M=%b S=%b W=%0d | exp M=%b S=%b W=%0d",
                         $time, U1.state, U1.count, light_main, light_side, walk,expMain, expSide, expWalk);
                errors = errors + 1;
            end
        end
    end

    // helper flags for each case
    integer saw_SG, saw_PG;

    // track if we reached SG/PG
    always @(posedge clk) begin
        if (rst) begin
            saw_SG <= 0;
            saw_PG <= 0;
        end else begin
            if (U1.state == 3'b011) saw_SG <= 1; // SG
            if (U1.state == 3'b101) saw_PG <= 1; // PG
        end
    end

    initial begin
        errors = 0;

        VS = 0; PB = 0;

        // reset
        rst = 1;
        repeat(2) @(posedge clk);
        rst = 0;

        // ============================
        //T1: VS=0 PB=0  (stay MG)
        // ============================
        $display("\nT1: VS=0 PB=0 (should stay in MG even after 60)");
        saw_SG = 0; saw_PG = 0;
        VS = 0; PB = 0;

        repeat(80) @(posedge clk);  // pass 60+
        if (saw_SG || saw_PG) begin
            $display("ERROR CASE1: entered SG/PG with no requests!");
            errors = errors + 1;
        end else begin
            $display("OK CASE1");
        end

        // ============================
        // T 2: VS=0 PB=1 (go to PG)
        // ============================
        // CASE2: VS=0 PB=1 (should reach PG)
	$display("\nT2: VS=0 PB=1 (should reach PG)");
	saw_SG = 0; saw_PG = 0;
	
	VS = 0;
	PB = 1;
	
	
	repeat(70) @(posedge clk);   // 70 > 60
	
	PB = 0; 
	repeat(200) @(posedge clk);
	
	if (!saw_PG) begin
	    $display("ERROR CASE2: did not reach PG!");
	    errors = errors + 1;
	end else begin
	    $display("OK CASE2");
	end

        // ============================
        // T 3: VS=1 PB=0 (go to SG)
        // ============================
        $display("\nT3: VS=1 PB=0 (should reach SG)");
        saw_SG = 0; saw_PG = 0;
        VS = 1; PB = 0;

        repeat(140) @(posedge clk);
        VS = 0;

        if (!saw_SG) begin
            $display("ERROR CASE3: did not reach SG!");
            errors = errors + 1;
        end else begin
            $display("OK CASE3");
        end

        // ============================
        //T4: VS=1 PB=1 (PB priority => PG)
        // ============================
        $display("\nT4: VS=1 PB=1 (should reach PG - PB priority)");
        saw_SG = 0; saw_PG = 0;
        VS = 1; PB = 1;
        repeat(3) @(posedge clk);
        PB = 0;

        repeat(160) @(posedge clk);
        VS = 0;

        if (!saw_PG) begin
            $display("ERROR CASE4: did not reach PG!");
            errors = errors + 1;
        end else begin
            $display("OK CASE4");
        end

        // ==========================================
        // T 5: VS at start, then PB during SG (queued)
        // ==========================================
        $display("\nT5: VS first, then press PB during SG (queued for next cycle)");
        saw_SG = 0; saw_PG = 0;
        VS = 1; PB = 0;

        // wait until we enter SG
        while (U1.state != 3'b011) @(posedge clk); // SG
        $display("Reached SG at t=%0t, now press PB inside SG", $time);

        // press PB during SG for 2 cycles
        PB = 1;
        repeat(2) @(posedge clk);
        PB = 0;

        // keep VS low now (doesn't matter)
        VS = 0;

        // wait enough time for SG to finish (40) then SY->AR-> (should choose PG due to queued PB)
        repeat(120) @(posedge clk);

        if (!saw_PG) begin
            $display("ERROR CASE5: did not reach PG after PB queued in SG!");
            errors = errors + 1;
        end else begin
            $display("OK CASE5");
        end

        // ============================
        // Final report
        // ============================
        if (errors == 0)
            $display("\nPASS: no errors");
        else
            $display("\nFAIL: errors=%0d", errors);

        $stop;
    end

endmodule
